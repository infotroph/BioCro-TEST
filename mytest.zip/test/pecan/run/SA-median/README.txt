runtype     : sensitivity analysis
workflow id : 2017-10-20-11-31-14
ensemble id : NA
pft name    : ALL PFT
quantile    : MEDIAN
trait       : ALL TRAIT
run id      : SA-median
model       : BIOCRO
model id    : 99000000001
site        : Bondville (US-Bo1)
site  id    : 753
met data    : 
start date  : 2004/01/01
end date    : 2004/12/30
hostname    : localhost
rundir      : /home/carya/test/pecan/run/SA-median
outdir      : /home/carya/test/pecan/out/SA-median
