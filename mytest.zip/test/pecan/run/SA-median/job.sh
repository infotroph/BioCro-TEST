#!/bin/bash
mkdir -p /home/carya/test/pecan/out/SA-median
cd /home/carya/test/pecan/run/SA-median
/home/carya/pecan/models/biocro/inst/biocro.Rscript /home/carya/test/pecan/run/SA-median /home/carya/test/pecan/out/SA-median
if [ $? -ne 0 ]; then
    echo ERROR IN MODEL RUN >&2
    exit 1
fi
cp  /home/carya/test/pecan/run/SA-median/README.txt /home/carya/test/pecan/out/SA-median/README.txt
