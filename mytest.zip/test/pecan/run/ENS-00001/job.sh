#!/bin/bash
mkdir -p /home/carya/test/pecan/out/ENS-00001
cd /home/carya/test/pecan/run/ENS-00001
/home/carya/pecan/models/biocro/inst/biocro.Rscript /home/carya/test/pecan/run/ENS-00001 /home/carya/test/pecan/out/ENS-00001
if [ $? -ne 0 ]; then
    echo ERROR IN MODEL RUN >&2
    exit 1
fi
cp  /home/carya/test/pecan/run/ENS-00001/README.txt /home/carya/test/pecan/out/ENS-00001/README.txt
