runtype     : ensemble
 workflow id :  2017-10-20-11-31-14 
 ensemble id :  NA 
 run         :  1 / 1 
 run id      :  ENS-00001 
 pft names   :  Miscanthus_x_giganteus 
 model       :  BIOCRO 
 model id    :  99000000001 
 site        :  Bondville (US-Bo1) 
 site  id    :  753 
 met data    :  
 start date  :  2004/01/01 
 end date    :  2004/12/30 
 hostname    :  localhost 
 rundir      :  /home/carya/test/pecan/run/ENS-00001 
 outdir      :  /home/carya/test/pecan/out/ENS-00001 
