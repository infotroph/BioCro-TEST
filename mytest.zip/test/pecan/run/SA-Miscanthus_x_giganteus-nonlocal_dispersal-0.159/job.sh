#!/bin/bash
mkdir -p /home/carya/test/pecan/out/SA-Miscanthus_x_giganteus-nonlocal_dispersal-0.159
cd /home/carya/test/pecan/run/SA-Miscanthus_x_giganteus-nonlocal_dispersal-0.159
/home/carya/pecan/models/biocro/inst/biocro.Rscript /home/carya/test/pecan/run/SA-Miscanthus_x_giganteus-nonlocal_dispersal-0.159 /home/carya/test/pecan/out/SA-Miscanthus_x_giganteus-nonlocal_dispersal-0.159
if [ $? -ne 0 ]; then
    echo ERROR IN MODEL RUN >&2
    exit 1
fi
cp  /home/carya/test/pecan/run/SA-Miscanthus_x_giganteus-nonlocal_dispersal-0.159/README.txt /home/carya/test/pecan/out/SA-Miscanthus_x_giganteus-nonlocal_dispersal-0.159/README.txt
